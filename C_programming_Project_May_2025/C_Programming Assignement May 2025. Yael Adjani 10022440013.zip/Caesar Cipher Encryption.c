#include <stdio.h>
#include <ctype.h>
#include <string.h>

int main() {
    char plaintext[1000];
    int key;

    
    printf("plaintext: ");
    fgets(plaintext, sizeof(plaintext), stdin);

    
    printf("Enter key: ");
    scanf("%d", &key);

    
    key = key % 26;

    char ciphertext[1000];
    int i = 0;

    while (plaintext[i] != '\0') {
        char ch = plaintext[i];

        if (isalpha(ch)) {
            if (isupper(ch)) {
                ciphertext[i] = ((ch - 'A' + key) % 26) + 'A';
            } else {
                ciphertext[i] = ((ch - 'a' + key) % 26) + 'a';
            }
        } else {
            
            ciphertext[i] = ch;
        }

        i++;
    }

    ciphertext[i] = '\0'; 

    printf("ciphertext: %s", ciphertext);

    return 0;
}